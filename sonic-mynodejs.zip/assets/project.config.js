let path = require('path');
module.exports = {
    build: {
        ejs2js: path.resolve(__dirname, './page/tpls') //构建ejs2js的范围
    }
};